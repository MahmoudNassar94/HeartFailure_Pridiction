import pickle
import streamlit as st
import pandas as pd

# Upload Data

data=pickle.load(open(r'C:\Users\Ahmed\Heart_Failure.sav','rb'))

# Streamlit Page

st.title('Heart Failure Prediction Web App')

st.sidebar.header('Feature selecting')

st.info('Easy Application For Predictiong Heart Failure Deseas')


Age=st.text_input('Age')
Sex=st.text_input('Sex')
ChestPainType=st.text_input('ChestPainType')
RestingBP=st.text_input('RestingBP')
Cholesterol=st.text_input('Cholesterol')
FastingBS=st.text_input('FastingBS')
RestingECG=st.text_input('RestingECG')
MaxHR=st.text_input('MaxHR')
ExerciseAngina=st.text_input('ExerciseAngina')
Oldpeak=st.text_input('Oldpeak')
ST_Slope=st.text_input('ST_Slope')

df=pd.DataFrame({'Age':[Age],'Sex':[Sex],'ChestPainType':[ChestPainType],'RestingBP':[RestingBP],'Cholesterol':[Cholesterol],
                 'FastingBS':[FastingBS],'RestingECG':[RestingECGe]},'MaxHR':[MaxHR]},'ExerciseAngina':[ExerciseAngina]},
                    'Oldpeak':[Oldpeak]},'ST_Slope':[ST_Slope]},index=[0])

Conf=st.sidebar.button('Confirm')
if Conf:
    result=data.predict(df)
    if result == 0:
       st.sidebar.write('The Patiant is Clear')
       st.sidebar.image('https://astrologer.swayamvaralaya.com/wp-content/uploads/2012/08/health1.jpg',width=50)
    else:
        st.sidebar.write('The Patiant Has Deseas')
        st.sidebar.image('https://brghealth.com/brg/wp-content/uploads/2020/01/diabetes.png',width=50)